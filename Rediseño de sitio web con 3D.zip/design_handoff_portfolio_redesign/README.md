# Handoff — Rediseño del portfolio de Alessandro Reyes

> Paquete de entrega para **Claude Code**. Contiene el brief completo, la
> especificación de diseño, el plan de trabajo por fases, y la referencia HTML
> del nuevo diseño. Migra el sitio actual (`alesso-24.github.io/portfolio`) a
> este nuevo diseño, sin perder contenido, con stack moderno, responsive y
> desplegado en GitHub Pages.

---

## 0. Cómo usar este paquete (léelo primero)

1. Abre el repositorio del portfolio en **Claude Code** (el repo de
   `github.com/alesso-24/portfolio`).
2. Copia esta carpeta `design_handoff_portfolio_redesign/` dentro del repo (o al
   menos este `README.md` y la carpeta `reference/`).
3. Pega en Claude Code el **prompt de arranque** de abajo, tal cual.
4. Claude Code ejecutará primero la **Fase 0 (Auditoría)** y creará un
   `PLAN.md`. Luego **se detiene** para que revises antes de continuar.
5. Cada vez que retomes (si te quedas sin tokens o pausas), abre el repo y di:
   *"Lee `PLAN.md` y continúa desde el próximo paso pendiente."*

### ⚡ Prompt de arranque (cópialo y pégalo en Claude Code)

```
Vas a migrar mi portfolio actual a un rediseño nuevo. Toda la guía está en
design_handoff_portfolio_redesign/README.md y la referencia visual en
design_handoff_portfolio_redesign/reference/Portfolio.dc.html (ábrelo en el
navegador para ver las animaciones).

Empieza SOLO con la FASE 0 del README:
1. Audita el repo actual y el contenido del sitio publicado.
2. Crea un PLAN.md en la raíz con el inventario de contenido y el plan por fases
   (usa la plantilla del README), con casillas de progreso.
3. Inicializa control de versiones si hace falta y haz un commit inicial.
Cuando termines la FASE 0, PÁRATE y muéstrame el PLAN.md y el inventario de
contenido para aprobarlo. No empieces a programar el diseño todavía.
```

---

## 1. Qué es este bundle (importante)

Los archivos en `reference/` son una **referencia de diseño hecha en HTML** — un
prototipo que muestra el look & feel, los colores, la tipografía y las
animaciones que quiero. **No es código de producción para copiar y pegar.**

`reference/Portfolio.dc.html` usa un runtime propietario (Design Components) que
**no** debes reproducir. Tu trabajo es **recrear ese diseño** en un stack real y
mantenible (ver Fase 1), no portar el HTML literal. Ábrelo en un navegador para
ver el movimiento; úsalo como fuente de verdad para medidas, colores y copy.

**Fidelidad: alta (hi-fi).** Colores, tipografía, espaciados y animaciones son
finales. Recréalo con precisión.

---

## 2. Misión y principios

- **Migrar, no empezar de cero el contenido:** todo el contenido real del sitio
  actual debe llegar al nuevo diseño (ver Fase 2). Cero pérdida de información.
- **Estética:** editorial, elegante, sobria. Fondo crema cálido, azul rey y
  naranja como acentos. Tipografía serif fina (Instrument Serif) + grotesca
  limpia (Hanken Grotesk).
- **Movimiento estilo Apple:** sutil, suave, con propósito. Reveals al hacer
  scroll, parallax ligero, scroll suave (smooth scroll), gradiente "aurora" que
  flota. Nada estridente ni "robótico".
- **Robustez de animaciones (regla de oro):** ninguna animación de entrada debe
  dejar contenido invisible si por cualquier motivo el motor de animación no
  corre. Toda animación que arranque ocultando un elemento debe tener un
  **fallback** (IntersectionObserver + un `setTimeout` de seguridad, o
  `prefers-reduced-motion`) que garantice que el contenido se ve igual. Respeta
  `prefers-reduced-motion: reduce` desactivando movimiento.
- **Calidad:** Lighthouse 95+ en Performance/Accesibilidad/Best Practices/SEO,
  responsive impecable de 320px a 4K, semántica y accesible.

---

## 3. Stack recomendado

El sitio actual es estático en GitHub Pages. Para conseguir las animaciones y
mantener Pages + máximo rendimiento, recomiendo:

| Capa | Tecnología | Por qué |
|---|---|---|
| Framework | **Astro** | Estático, 0 JS por defecto, islas para interactividad, Lighthouse altísimo, deploy a Pages trivial. Ideal para portfolios. |
| Estilos | **Tailwind CSS** | Tokens consistentes, responsive rápido. Define los colores/fuentes de abajo en `tailwind.config`. |
| Animaciones scroll | **GSAP + ScrollTrigger** | Reveals y parallax precisos y con buen rendimiento. |
| Scroll suave | **Lenis** | El "feel" Apple de scroll suave. Sincronízalo con ScrollTrigger. |
| Tipografía | **Fontsource** (self-host) de Instrument Serif y Hanken Grotesk | Evita FOUT y dependencia de Google. |
| Aurora del hero | **CSS puro** (radial-gradients + blur + @keyframes) | Sin WebGL; ligero y elegante. |

> Alternativa válida si prefieres: **Vite + React + Framer Motion + Lenis**, con
> `gh-pages` para desplegar. Elige UNO y déjalo documentado en `PLAN.md`.
> No uses Three.js/WebGL (lo probamos y no encaja con la estética buscada).

**Decisión libre:** si auditando el repo ves que ya hay un stack montado,
respétalo y adapta el diseño a él en vez de reescribir todo.

---

## 4. Plan por fases — y `PLAN.md`

En la Fase 0, **crea un `PLAN.md` en la raíz del repo** usando esta plantilla.
Mantenlo actualizado al final de cada paso (marca casillas, escribe el "Estado
actual / Próximo paso"). Es lo que te permitirá reanudar si te pausan.

<details>
<summary><b>Plantilla de <code>PLAN.md</code></b></summary>

```markdown
# PLAN — Migración del portfolio al nuevo diseño

## Estado actual
- Fase en curso: <p.ej. Fase 2 — Migración de contenido>
- Último paso completado: <...>
- 👉 Próximo paso: <lo primero que debe hacerse al reanudar>

## Decisiones técnicas
- Stack elegido: <Astro + Tailwind + GSAP + Lenis>
- Base path de Pages: /portfolio/
- Rama de trabajo: redesign

## Inventario de contenido (del sitio viejo)
| Contenido | Texto/links exactos | Sección nueva | ¿Migrado? |
|---|---|---|---|
| Nombre / rol | ... | Hero | [ ] |
| Tagline | ... | Hero | [ ] |
| Proyectos | ... | Work | [ ] |
| Publicaciones | ... | Research | [ ] |
| Stats | ... | Numbers | [ ] |
| Contacto / redes | email, GitHub, LinkedIn | Contact | [ ] |
| Imágenes/assets | rutas | varias | [ ] |

## Fases
- [ ] Fase 0 — Auditoría + PLAN.md + git init + commit inicial
- [ ] Fase 1 — Setup del stack (Astro/Tailwind/GSAP/Lenis, fuentes, estructura)
- [ ] Fase 2 — Migración de contenido (todo el contenido real al nuevo layout)
- [ ] Fase 3 — Implementación del diseño (secciones, tokens, animaciones)
- [ ] Fase 4 — Responsive + accesibilidad + performance + SEO
- [ ] Fase 5 — Git/GitHub + GitHub Pages (Actions) + verificación en producción

## Registro de cambios
- <fecha> — <qué se hizo> — <commit hash>
```
</details>

### Fase 0 — Auditoría (haz esto primero y PÁRATE)
1. Lista la estructura del repo y el stack actual (¿vanilla? ¿algún framework?).
2. Extrae **todo** el contenido del sitio actual: textos, títulos, descripciones
   de proyectos, publicaciones, stats, enlaces (email, GitHub, LinkedIn) y la
   ruta de **todas las imágenes/assets** (guárdalas, se reutilizan).
3. Vuelca ese contenido en la tabla de inventario del `PLAN.md`.
4. Detecta lo que NO está en la referencia pero existe en el viejo (no lo
   pierdas: o lo ubicas en una sección nueva o lo anotas como pendiente).
5. `git init` si no hay repo, crea rama `redesign`, commit inicial.
6. **Detente** y muestra `PLAN.md` + inventario para aprobación.

### Fase 1 — Setup
- Monta el stack elegido. Configura `tailwind.config` con los tokens (Sección 6).
- Self-host de fuentes (Instrument Serif, Hanken Grotesk). Define `prefers-reduced-motion`.
- Configura el `base`/`site` de Astro para Pages (Sección 8).
- Commit: `chore: project scaffolding`.

### Fase 2 — Migración de contenido
- Crea un origen de datos (p.ej. `src/content/` o un `data.ts`) con TODO el
  contenido real del inventario. El diseño consume ese origen — nada de copy
  hardcodeado suelto.
- Copia las imágenes reales del sitio viejo a `public/`/`assets/` y úsalas en
  Work/Hero (en la referencia hay placeholders).
- Marca cada fila del inventario como migrada.

### Fase 3 — Implementación del diseño
- Construye las secciones (Sección 6) con los tokens y animaciones exactos.
- Implementa los 3 estilos de hero (Aurora por defecto; Foto y Tipografía como
  variantes — puedes dejar Aurora y dejar las otras documentadas/opcionales).

### Fase 4 — Responsive + calidad
- Ver Sección 7. Prueba 320 / 768 / 1024 / 1440 / 2560 px.

### Fase 5 — Deploy
- Ver Sección 8. Verifica el sitio en vivo en `alesso-24.github.io/portfolio`.

---

## 5. Migración de contenido (qué mapear)

El sitio actual es el portfolio de **Alessandro Reyes — Mechatronics Engineer
(Embedded AI & Robotics)**. Contenido conocido que debe aparecer:

- **Identidad:** Alessandro Reyes · Mechatronics Engineer · Embedded AI & Robotics.
- **Tagline:** "Building AI that survives contact with real hardware."
- **Logros reales:** 2× autor IEEE (CASE 2026 y BDAI 2026); robótica competitiva
  LARC 2025; disponible para prácticas verano 2026.
- **Enlaces:** GitHub `github.com/alesso-24` · email real · LinkedIn real
  (extráelos del sitio viejo; en la referencia están como placeholder).
- **Imágenes de proyectos:** usa las reales del sitio viejo.

Audita el sitio para capturar **el texto exacto** (descripciones de proyectos,
fechas, números de stats) y respétalo. Si el viejo tiene secciones extra
(estudios, CV, etc.) decídelas con el usuario o ubícalas en una sección
coherente — no las elimines silenciosamente.

---

## 6. Especificación de diseño

### 6.1 Tokens de color
```
--cream         #f3ede1   /* fondo principal */
--cream-alt     #efe7d8   /* secciones alternas (marquee, Work) */
--ink           #211f1a   /* texto principal */
--muted         #6f6a5f   /* texto secundario */
--muted-soft    #534f46   /* párrafos sobre crema */
--hairline      #8a8579   /* labels apagados / líneas */
--blue          #2540c0   /* AZUL REY: marca, CTA, sección Contact full-bleed */
--orange        #ea6a2e   /* NARANJA: acento, itálicas, detalles, puntos */
--on-blue       #f3ede1   /* texto sobre azul */
```
Selección de texto: fondo azul, texto crema.

### 6.2 Tipografía
- **Display / serif:** `Instrument Serif` (400 y *italic*). Para H1–H3, números
  grandes de stats, marquee, número de publicaciones. Las palabras clave van en
  *itálica* y color (naranja en hero/contact, azul en about).
- **Texto / UI:** `Hanken Grotesk` (300–700). Párrafos, nav, botones, labels.
- **Labels:** Hanken Grotesk 600, ~12px, MAYÚSCULAS, `letter-spacing: 0.16em`,
  color `--muted`, con un punto naranja de 9px a la izquierda.
- Escala display con `clamp()`: H1 hero `clamp(46px, 9.4vw, 160px)`,
  `line-height: 0.96`, `letter-spacing: -0.015em`. H2 secciones
  `clamp(32px, 4.8–6vw, 72–92px)`. Cuerpo 15–18px, `line-height` 1.55–1.6.

### 6.3 Forma y profundidad
- Cards e imágenes: `border-radius: 18px`. Botones/pills: `100px`. Avatar nav: círculo.
- Sombras de color en cards: `0 24px 60px -30px rgba(37,64,192,.4)` (azul) y
  `0 22px 50px -30px rgba(234,106,46,.4)` (naranja), según la card.
- Líneas divisorias `rgba(33,31,26,.12–.16)`; en research/listas, borde superior fino.

### 6.4 Secciones (orden y contenido)
1. **Nav** (fijo, blur, `rgba(243,237,225,.72)`): avatar azul "A" + nombre ·
   links Work/Research/About/Contact (ocultos < 860px) · pill negra "Open to
   Summer 2026" con punto naranja pulsante.
2. **Hero** (100vh): label "Mechatronics · Embedded AI · Robotics" · H1 serif con
   "real hardware." en itálica naranja · párrafo · CTAs **View work** (azul) y
   **Get in touch** (outline) · "Scroll" abajo-derecha. Fondo = **Aurora**
   (3 blobs radiales azul/naranja/crema con `blur(60–82px)` que flotan con
   `@keyframes` 17–23s, más una máscara radial crema para fundir). Variantes de
   hero opcionales: **Foto** (imagen a sangre + degradado crema para legibilidad)
   y **Tipografía** (monograma "AR" gigante difuminado al fondo).
3. **Marquee** (`--cream-alt`): términos en Instrument Serif separados por ✦
   naranja, desplazándose `translateX(-50%)` en loop (38s lineal).
4. **About**: label "Who I am" · H2 serif grande con frase clave en *itálica*
   azul · párrafo + link "Read the research →" con subrayado naranja.
5. **Numbers / Stats** (grid 4 col → 2 en móvil): número serif gigante azul
   (`2×`, `'25`, `100%`, `'26`), línea, título, descripción.
6. **Work** (`--cream-alt`): título "Projects & *real systems*" · 1 card grande
   16:9 + fila de 2 cards 4:3. Cada card: imagen (radius 18, sombra de color) +
   tag (Research/Robotics) + título serif + categoría + descripción. Hover sutil.
7. **Research / Publications**: filas (nº serif naranja · título serif ·
   "2026 ↗" azul) con bordes finos. IEEE CASE 2026 e IEEE BDAI 2026.
8. **Contact** (full-bleed **azul rey**, texto crema): glow naranja radial · H2
   serif gigante "Let's build something *real.*" · botón naranja con email +
   botones outline GitHub/LinkedIn.
9. **Footer** (crema): © año + nombre · "Designed for the real world" en itálica.

### 6.5 Animaciones (con easing y fallback)
- **Easing global:** `cubic-bezier(0.16, 1, 0.3, 1)`.
- **Reveal al scroll** (`[data-reveal]`): de `opacity:0; translateY(34px)` a
  visible, dur ~0.9s, con `stagger`/delay por elemento. Dispara con
  IntersectionObserver (threshold ~0.12). **Fallback obligatorio:** un
  `setTimeout` de seguridad (~4.5s) o estado por defecto visible para que nunca
  quede oculto si el observer/frames no corren.
- **Entrada del hero** (kinetic): label/H1/párrafo/CTAs entran con
  `opacity 0→1`, `translateY(30→0)`, `blur(7px→0)`, dur ~1.05s, stagger
  40/120/260/360ms. **Fallback obligatorio** (timeout o IO) que fuerce visible.
- **Aurora:** blobs con `@keyframes` `translate + scale` 17–23s `ease-in-out infinite`.
- **Marquee:** 38s `linear infinite`, contenido duplicado para loop perfecto.
- **Parallax:** al hacer scroll, el texto del hero `translateY(scrollY*0.16)` y
  baja opacidad; el fondo `translateY(scrollY*0.26)` y escala leve. Con GSAP usa
  ScrollTrigger + Lenis para suavidad.
- **prefers-reduced-motion:** desactiva todo el movimiento y muestra estados finales.

---

## 7. Responsive, accesibilidad y rendimiento

- **Breakpoints:** móvil-first. Verifica 320, 375, 768, 1024, 1440, 2560 px.
  Nav: links colapsan a menú < 860px (haz un menú móvil accesible). Stats 4→2 col.
  Work: fila de 2 → 1 col. Tamaños con `clamp()`; nada de overflow horizontal.
- **Hit targets** ≥ 44px. Foco visible en todos los interactivos. `alt` en imágenes.
  Contraste AA (texto sobre crema y sobre azul cumple; verifica el naranja sobre
  crema para texto pequeño — úsalo solo en grande/decorativo).
- **HTML semántico:** `header/nav/main/section/footer`, jerarquía de headings,
  landmarks, `aria-*` donde aplique.
- **Rendimiento:** imágenes optimizadas (AVIF/WebP, `srcset`, `loading="lazy"`,
  width/height para evitar CLS). Self-host de fuentes con `font-display: swap` y
  `preload`. JS mínimo (islas). Objetivo Lighthouse ≥ 95 en las 4 categorías.
- **SEO:** title, meta description, Open Graph/Twitter (ya existen en el viejo:
  consérvalos/actualízalos), `og:image`, `sitemap`, `robots`, `lang` correcto,
  canonical a la URL de Pages.

---

## 8. Git, GitHub y despliegue en GitHub Pages

### Control de versiones
- Trabaja en rama `redesign`; PRs/commits pequeños y descriptivos
  (Conventional Commits: `feat:`, `fix:`, `chore:`, `refactor:`…).
- Commit por fase (mínimo) y al cerrar cada sección grande. Registra el hash en
  `PLAN.md`. Al finalizar y aprobar, merge a `main`.

### Despliegue (Astro → Pages, project site)
El sitio es un **project site**, así que la base es `/portfolio/`.

`astro.config.mjs`:
```js
export default defineConfig({
  site: 'https://alesso-24.github.io',
  base: '/portfolio',
});
```
Usa `import.meta.env.BASE_URL` (o el helper de Astro) para rutas de assets/links.

Workflow `/.github/workflows/deploy.yml` (Actions oficiales de Pages):
```yaml
name: Deploy to GitHub Pages
on:
  push: { branches: [main] }
  workflow_dispatch:
permissions: { contents: read, pages: write, id-token: write }
concurrency: { group: pages, cancel-in-progress: true }
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci
      - run: npm run build
      - uses: actions/upload-pages-artifact@v3
        with: { path: ./dist }
  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment: { name: github-pages, url: '${{ steps.deployment.outputs.page_url }}' }
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```
En el repo: **Settings → Pages → Source: GitHub Actions**. Añade `.nojekyll`.
Tras el deploy, **verifica en producción** que cargan fuentes, imágenes y
animaciones, y que no hay 404 por el `base`.

> Si eliges un stack no-Astro, ajusta build dir (`build`/`out`) y, para React con
> rutas, fija el `base`/`homepage` a `/portfolio/`.

---

## 9. Definition of Done
- [ ] Todo el contenido del sitio viejo migrado (inventario 100% en `PLAN.md`).
- [ ] Diseño fiel a la referencia (tokens, tipografía, secciones, animaciones).
- [ ] Animaciones con fallback (nada queda invisible) y `prefers-reduced-motion`.
- [ ] Responsive 320px–4K sin overflow; menú móvil accesible.
- [ ] Imágenes reales optimizadas; email/GitHub/LinkedIn reales.
- [ ] Lighthouse ≥ 95 en las 4 categorías.
- [ ] Desplegado y verificado en `https://alesso-24.github.io/portfolio`.
- [ ] `PLAN.md` actualizado y mergeado a `main`.

---

## Archivos de referencia en este bundle
- `reference/Portfolio.dc.html` — diseño nuevo (ábrelo en el navegador para ver
  el movimiento). Fuente de verdad para medidas, colores, copy y animaciones.
- `reference/image-slot.js` — solo apoyo del prototipo (no migrar).
- `reference/hero-aurora.png` — captura del hero con el fondo Aurora.
